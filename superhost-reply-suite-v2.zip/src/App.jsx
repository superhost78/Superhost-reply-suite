import { useState, useEffect } from "react";
import { LS_CHECKOUT_URL, TRIAL_DAYS, getTrialStart, getTrialDaysRemaining, isPaywalled } from "./config.js";

// ── Design tokens ──────────────────────────────────────────────
const C = {
  teal: "#0D9488", tealDark: "#0F766E", tealLight: "#CCFBF1", tealGhost: "#F0FDFA",
  sand: "#FAFAF7", ink: "#111827", muted: "#6B7280", border: "#E5E7EB", white: "#FFFFFF",
  redSoft: "#FEF2F2", redBorder: "#FECACA", red: "#DC2626",
  amber: "#D97706", amberSoft: "#FFFBEB", amberBorder: "#FDE68A",
  green: "#059669", greenSoft: "#ECFDF5", greenBorder: "#A7F3D0",
  purple: "#7C3AED", purpleSoft: "#F5F3FF", purpleBorder: "#DDD6FE",
};

const TOOLS = [
  { id: "bad",      label: "Bad Review",      icon: "🔴", color: C.red,    headline: "Turn a bad review into a trust signal",       sub: "Future guests read how you respond more than what they said." },
  { id: "positive", label: "Positive Review",  icon: "⭐", color: C.amber,  headline: "Say thank you like you mean it",               sub: "Hosts who reply to great reviews get more great reviews." },
  { id: "neutral",  label: "Neutral Review",   icon: "🟡", color: C.teal,   headline: "The 3-star review is the sneakiest threat",    sub: "A lukewarm response handled well shows future guests who you are." },
  { id: "dispute",  label: "Dispute & Flag",   icon: "⚖️", color: C.purple, headline: "Build your escalation case — word by word",   sub: "Use the guest's own words to write a dispute Airbnb can't ignore." },
];

const TONES = ["Professional", "Warm", "Firm", "Apologetic"];
const TONE_ICONS = { Professional: "🎩", Warm: "🤝", Firm: "⚖️", Apologetic: "🕊️" };

const BAD_ISSUES = ["Cleanliness complaint","Amenity not as described","Noise complaint","Check-in issue","Host communication","Safety concern (unfounded)","Retaliatory / suspected fake","Pricing / value complaint","Other"];
const DISPUTE_GROUNDS = ["Retaliatory review after dispute","Review violates Airbnb content policy","Guest caused damage and reviewed negatively","Review contains false factual claims","Guest broke house rules, then reviewed","Review left by wrong guest / error","Extortion attempt prior to review"];

// ── Prompt builders ─────────────────────────────────────────────
function buildPrompt(toolId, f) {
  const prop = f.propertyName ? ` for "${f.propertyName}"` : "";
  if (toolId === "bad") return `You are an expert Airbnb Superhost consultant. Generate a ${f.tone.toLowerCase()} public response to this bad review${prop}.
Complaint: ${f.issueType}
Review: "${f.review}"
Rules: Under 200 words. ${f.tone === "Firm" ? "Politely correct inaccuracies." : ""} ${f.tone === "Apologetic" ? "Acknowledge with genuine empathy." : ""} ${f.issueType === "Retaliatory / suspected fake" ? "Professionally note discrepancies so future guests can read between the lines." : ""} End with a forward-looking note. Do NOT start with 'Dear Guest'. Write ONLY the response.`;

  if (toolId === "positive") return `You are an expert Airbnb Superhost consultant. Generate a ${f.tone.toLowerCase()} public thank-you response to this positive review${prop}.
Review: "${f.review}"
${f.stayHighlights ? `Host notes: ${f.stayHighlights}` : ""}
Rules: Under 150 words. Reference something specific from the review. Sound like a real person. Invite them back. Do NOT start with 'Thank you so much for your wonderful review!'. Write ONLY the response.`;

  if (toolId === "neutral") return `You are an expert Airbnb Superhost consultant. Generate a thoughtful public response to this neutral/mixed review${prop}.
Review: "${f.review}"
${f.yourContext ? `Context (do not quote directly): ${f.yourContext}` : ""}
Rules: Under 180 words. Acknowledge what they enjoyed, address what fell short without being defensive. Turn lukewarm into a trust signal. Write ONLY the response.`;

  if (toolId === "dispute") return `You are an expert Airbnb dispute specialist. Write a formal review removal request to Airbnb support${prop}.
Grounds: ${f.disputeGround}
Review: "${f.review}"
${f.yourContext ? `Evidence: ${f.yourContext}` : ""}
Rules: Under 300 words. Open with clear policy violation statement. Quote relevant review language. Reference Airbnb Review Policy. Factual and calm. Request specific action: review removal. Write ONLY the dispute message.`;
}

// ── Reusable components ─────────────────────────────────────────
function FieldLabel({ children, optional }) {
  return <label style={{ fontSize: "13px", fontWeight: "600", color: C.ink, marginBottom: "6px", display: "block" }}>{children}{optional && <span style={{ color: C.muted, fontWeight: 400 }}> (optional)</span>}</label>;
}

function Input({ value, onChange, placeholder }) {
  return <input value={value} onChange={onChange} placeholder={placeholder} style={{ width: "100%", border: `1.5px solid ${C.border}`, borderRadius: "10px", padding: "11px 14px", fontSize: "14px", color: C.ink, fontFamily: "inherit", background: C.white, boxSizing: "border-box" }} />;
}

function Textarea({ value, onChange, placeholder, rows = 5, max = 1000 }) {
  return <div><textarea value={value} onChange={e => onChange(e.target.value.slice(0, max))} placeholder={placeholder} rows={rows} style={{ width: "100%", border: `1.5px solid ${C.border}`, borderRadius: "10px", padding: "12px 14px", fontSize: "14px", color: C.ink, lineHeight: "1.65", resize: "vertical", fontFamily: "inherit", background: C.white, boxSizing: "border-box" }} /><div style={{ fontSize: "11px", color: C.muted, textAlign: "right", marginTop: "3px" }}>{value.length}/{max}</div></div>;
}

function Select({ value, onChange, options, placeholder }) {
  return <select value={value} onChange={e => onChange(e.target.value)} style={{ width: "100%", border: `1.5px solid ${C.border}`, borderRadius: "10px", padding: "11px 14px", fontSize: "14px", color: value ? C.ink : C.muted, fontFamily: "inherit", background: C.white, boxSizing: "border-box", appearance: "none", cursor: "pointer" }}><option value="">{placeholder}</option>{options.map(o => <option key={o} value={o}>{o}</option>)}</select>;
}

function ToneSelector({ tone, setTone }) {
  return <div style={{ display: "flex", gap: "8px", flexWrap: "wrap" }}>{TONES.map(t => <div key={t} onClick={() => setTone(t)} style={{ padding: "8px 14px", borderRadius: "20px", cursor: "pointer", border: `1.5px solid ${tone === t ? C.teal : C.border}`, background: tone === t ? C.tealLight : C.white, color: tone === t ? C.tealDark : C.muted, fontSize: "13px", fontWeight: tone === t ? "600" : "500", transition: "all 0.15s" }}>{TONE_ICONS[t]} {t}</div>)}</div>;
}

function GenerateBtn({ can, loading, onClick, label = "Generate Response →" }) {
  return <button onClick={onClick} disabled={!can || loading} style={{ width: "100%", padding: "14px", borderRadius: "10px", border: "none", background: can && !loading ? `linear-gradient(135deg, ${C.teal} 0%, ${C.tealDark} 100%)` : C.border, color: can && !loading ? C.white : C.muted, fontSize: "15px", fontWeight: "700", cursor: can && !loading ? "pointer" : "not-allowed", transition: "all 0.15s" }}>{loading ? <span style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "8px" }}><span style={{ width: "15px", height: "15px", border: `2px solid rgba(255,255,255,0.4)`, borderTopColor: C.white, borderRadius: "50%", animation: "spin 0.7s linear infinite", display: "inline-block" }} />Crafting your response…</span> : label}</button>;
}

function OutputCard({ output, onRegenerate, onCopy, copied }) {
  return <div style={{ background: C.white, border: `1.5px solid ${C.teal}`, borderRadius: "14px", padding: "24px", marginTop: "20px", boxShadow: `0 0 0 4px ${C.tealLight}`, animation: "fadeIn 0.3s ease" }}>
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "14px" }}>
      <div style={{ fontSize: "11px", fontWeight: "700", color: C.tealDark, letterSpacing: "0.8px", textTransform: "uppercase" }}>✦ Your response</div>
      <button onClick={onCopy} style={{ padding: "7px 14px", background: C.tealLight, color: C.tealDark, border: "none", borderRadius: "7px", fontSize: "12px", fontWeight: "600", cursor: "pointer" }}>{copied ? "✓ Copied!" : "Copy"}</button>
    </div>
    <div style={{ fontSize: "15px", color: C.ink, lineHeight: "1.8", whiteSpace: "pre-wrap" }}>{output}</div>
    <div style={{ height: "1px", background: C.border, margin: "18px 0" }} />
    <button onClick={onRegenerate} style={{ width: "100%", padding: "11px", background: C.tealGhost, color: C.tealDark, border: `1px solid ${C.tealLight}`, borderRadius: "8px", fontSize: "13px", fontWeight: "600", cursor: "pointer" }}>↻ Regenerate</button>
    <div style={{ background: C.tealLight, border: `1px solid ${C.teal}`, borderRadius: "10px", padding: "11px 14px", fontSize: "13px", color: C.tealDark, marginTop: "14px", lineHeight: "1.5" }}>💡 <strong>Pro tip:</strong> Post your response within 48 hours. Speed signals attentiveness to future guests.</div>
  </div>;
}

// ── Paywall modal ───────────────────────────────────────────────
function PaywallModal({ onClose }) {
  return <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.6)", zIndex: 100, display: "flex", alignItems: "center", justifyContent: "center", padding: "20px" }}>
    <div style={{ background: C.white, borderRadius: "20px", padding: "36px 28px", maxWidth: "420px", width: "100%", textAlign: "center", animation: "fadeIn 0.25s ease" }}>
      <div style={{ fontSize: "40px", marginBottom: "12px" }}>🏡</div>
      <div style={{ fontSize: "22px", fontWeight: "800", color: C.ink, letterSpacing: "-0.4px", marginBottom: "8px" }}>You've used your free responses</div>
      <div style={{ fontSize: "14px", color: C.muted, lineHeight: "1.6", marginBottom: "24px" }}>Unlock unlimited responses across all four tools — bad reviews, positive replies, neutral reviews, and dispute drafts.</div>
      <div style={{ background: C.tealGhost, border: `1px solid ${C.tealLight}`, borderRadius: "14px", padding: "20px", marginBottom: "24px" }}>
        <div style={{ fontSize: "32px", fontWeight: "800", color: C.teal, letterSpacing: "-1px" }}>$12<span style={{ fontSize: "16px", fontWeight: "500", color: C.muted" }}>/month</span></div>
        <div style={{ fontSize: "13px", color: C.muted, marginTop: "4px" }}>Cancel anytime</div>
        <div style={{ marginTop: "14px", display: "flex", flexDirection: "column", gap: "8px", textAlign: "left" }}>
          {["Unlimited responses across all 4 tools","Bad review responses that protect your reputation","Positive & neutral review replies","Professional Airbnb dispute messages"].map(f => <div key={f} style={{ fontSize: "13px", color: C.ink, display: "flex", alignItems: "center", gap: "8px" }}><span style={{ color: C.teal, fontWeight: "700" }}>✓</span>{f}</div>)}
        </div>
      </div>
      <a href={LS_CHECKOUT_URL} target="_blank" rel="noopener noreferrer" style={{ display: "block", width: "100%", padding: "15px", background: `linear-gradient(135deg, ${C.teal} 0%, ${C.tealDark} 100%)`, color: C.white, borderRadius: "10px", fontSize: "15px", fontWeight: "700", textDecoration: "none", marginBottom: "12px" }}>Unlock Full Access →</a>
      <button onClick={onClose} style={{ background: "none", border: "none", color: C.muted, fontSize: "13px", cursor: "pointer" }}>Maybe later</button>
    </div>
  </div>;
}

// ── Landing page ────────────────────────────────────────────────
function LandingPage({ onGetStarted }) {
  return <div style={{ minHeight: "100vh", background: C.sand }}>
    <div style={{ background: C.white, borderBottom: `1px solid ${C.border}`, padding: "16px 28px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
      <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
        <div style={{ width: "34px", height: "34px", background: `linear-gradient(135deg, ${C.teal} 0%, ${C.tealDark} 100%)`, borderRadius: "9px", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "17px" }}>🏡</div>
        <div>
          <div style={{ fontSize: "16px", fontWeight: "800", color: C.ink, letterSpacing: "-0.4px" }}>Superhost Reply Suite</div>
          <div style={{ fontSize: "11px", color: C.muted, letterSpacing: "0.4px", textTransform: "uppercase" }}>AI Review Toolkit</div>
        </div>
      </div>
      <button onClick={onGetStarted} style={{ padding: "9px 18px", background: C.teal, color: C.white, border: "none", borderRadius: "8px", fontSize: "13px", fontWeight: "600", cursor: "pointer" }}>Try Free →</button>
    </div>

    <div style={{ maxWidth: "680px", margin: "0 auto", padding: "60px 24px 80px", textAlign: "center" }}>
      <div style={{ display: "inline-block", background: C.tealLight, color: C.tealDark, fontSize: "12px", fontWeight: "600", padding: "5px 12px", borderRadius: "20px", letterSpacing: "0.5px", marginBottom: "20px" }}>✦ Built for Airbnb Superhosts</div>
      <h1 style={{ fontSize: "40px", fontWeight: "800", color: C.ink, letterSpacing: "-1px", lineHeight: "1.15", marginBottom: "16px" }}>Stop losing bookings<br />to bad reviews</h1>
      <p style={{ fontSize: "16px", color: C.muted, lineHeight: "1.65", marginBottom: "36px", maxWidth: "480px", margin: "0 auto 36px" }}>Generate professional, on-brand responses to every type of guest review in seconds. Future guests judge you by how you respond.</p>
      <button onClick={onGetStarted} style={{ padding: "16px 36px", background: `linear-gradient(135deg, ${C.teal} 0%, ${C.tealDark} 100%)`, color: C.white, border: "none", borderRadius: "12px", fontSize: "16px", fontWeight: "700", cursor: "pointer", marginBottom: "12px", display: "block", width: "100%", maxWidth: "320px", margin: "0 auto 12px" }}>Start your 3-day free trial →</button>
      <div style={{ fontSize: "13px", color: C.muted }}>No credit card required · $12/month after trial</div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "14px", marginTop: "56px", textAlign: "left" }}>
        {[
          { icon: "🔴", title: "Bad Review Response", desc: "Turn a 1-star nightmare into a trust signal for future guests." },
          { icon: "⭐", title: "Positive Review Reply", desc: "Thank guests in a way that feels personal, not automated." },
          { icon: "🟡", title: "Neutral Review Follow-up", desc: "The 3-star review is the sneakiest threat. Handle it right." },
          { icon: "⚖️", title: "Dispute & Flag Drafter", desc: "Build a formal Airbnb removal request using their own policy." },
        ].map(f => <div key={f.title} style={{ background: C.white, border: `1px solid ${C.border}`, borderRadius: "12px", padding: "18px" }}>
          <div style={{ fontSize: "22px", marginBottom: "8px" }}>{f.icon}</div>
          <div style={{ fontSize: "14px", fontWeight: "700", color: C.ink, marginBottom: "4px" }}>{f.title}</div>
          <div style={{ fontSize: "13px", color: C.muted, lineHeight: "1.5" }}>{f.desc}</div>
        </div>)}
      </div>

      <div style={{ marginTop: "56px", background: C.white, border: `1px solid ${C.border}`, borderRadius: "16px", padding: "32px" }}>
        <div style={{ fontSize: "28px", fontWeight: "800", color: C.teal, letterSpacing: "-0.5px", marginBottom: "4px" }}>$12<span style={{ fontSize: "16px", fontWeight: "500", color: C.muted }}>/month</span></div>
        <div style={{ fontSize: "14px", color: C.muted, marginBottom: "20px" }}>Unlimited responses · Cancel anytime</div>
        <button onClick={onGetStarted} style={{ padding: "14px 28px", background: `linear-gradient(135deg, ${C.teal} 0%, ${C.tealDark} 100%)`, color: C.white, border: "none", borderRadius: "10px", fontSize: "15px", fontWeight: "700", cursor: "pointer", width: "100%" }}>Start your free {TRIAL_DAYS}-day trial →</button>
      </div>
    </div>
  </div>;
}

// ── Tool panels ─────────────────────────────────────────────────
function BadReviewTool({ onGenerate, loading, output, copied, onCopy }) {
  const [review, setReview] = useState(""); const [issueType, setIssueType] = useState(""); const [tone, setTone] = useState("Professional"); const [propertyName, setPropertyName] = useState("");
  const can = review.trim().length > 10 && !!issueType;
  const prompt = () => buildPrompt("bad", { review, tone, propertyName, issueType });
  return <div>
    <div style={{ marginBottom: "14px" }}><FieldLabel optional>Property name</FieldLabel><Input value={propertyName} onChange={e => setPropertyName(e.target.value)} placeholder="e.g. SugarDolphin Beach Condo" /></div>
    <div style={{ marginBottom: "14px" }}><FieldLabel>Complaint type</FieldLabel><Select value={issueType} onChange={setIssueType} options={BAD_ISSUES} placeholder="Select complaint type…" /></div>
    <div style={{ marginBottom: "14px" }}><FieldLabel>Guest review</FieldLabel><Textarea value={review} onChange={setReview} placeholder="Paste the exact review text here…" rows={5} /></div>
    <div style={{ marginBottom: "18px" }}><FieldLabel>Response tone</FieldLabel><ToneSelector tone={tone} setTone={setTone} /></div>
    <GenerateBtn can={can} loading={loading} onClick={() => onGenerate(prompt())} />
    {output && <OutputCard output={output} onRegenerate={() => onGenerate(prompt())} onCopy={onCopy} copied={copied} />}
  </div>;
}

function PositiveReviewTool({ onGenerate, loading, output, copied, onCopy }) {
  const [review, setReview] = useState(""); const [tone, setTone] = useState("Warm"); const [propertyName, setPropertyName] = useState(""); const [stayHighlights, setStayHighlights] = useState("");
  const can = review.trim().length > 10;
  const prompt = () => buildPrompt("positive", { review, tone, propertyName, stayHighlights });
  return <div>
    <div style={{ marginBottom: "14px" }}><FieldLabel optional>Property name</FieldLabel><Input value={propertyName} onChange={e => setPropertyName(e.target.value)} placeholder="e.g. SugarDolphin Beach Condo" /></div>
    <div style={{ marginBottom: "14px" }}><FieldLabel>Guest review</FieldLabel><Textarea value={review} onChange={setReview} placeholder="Paste the 5-star review here…" rows={4} /></div>
    <div style={{ marginBottom: "14px" }}><FieldLabel optional>Anything specific to highlight?</FieldLabel><Input value={stayHighlights} onChange={e => setStayHighlights(e.target.value)} placeholder="e.g. They mentioned their anniversary, loved the ocean view" /></div>
    <div style={{ marginBottom: "18px" }}><FieldLabel>Response tone</FieldLabel><ToneSelector tone={tone} setTone={setTone} /></div>
    <GenerateBtn can={can} loading={loading} onClick={() => onGenerate(prompt())} />
    {output && <OutputCard output={output} onRegenerate={() => onGenerate(prompt())} onCopy={onCopy} copied={copied} />}
  </div>;
}

function NeutralReviewTool({ onGenerate, loading, output, copied, onCopy }) {
  const [review, setReview] = useState(""); const [tone, setTone] = useState("Professional"); const [propertyName, setPropertyName] = useState(""); const [yourContext, setYourContext] = useState("");
  const can = review.trim().length > 10;
  const prompt = () => buildPrompt("neutral", { review, tone, propertyName, yourContext });
  return <div>
    <div style={{ marginBottom: "14px" }}><FieldLabel optional>Property name</FieldLabel><Input value={propertyName} onChange={e => setPropertyName(e.target.value)} placeholder="e.g. SugarDolphin Beach Condo" /></div>
    <div style={{ marginBottom: "14px" }}><FieldLabel>Guest review</FieldLabel><Textarea value={review} onChange={setReview} placeholder="Paste the neutral or mixed review here…" rows={4} /></div>
    <div style={{ marginBottom: "14px" }}><FieldLabel optional>What you've since fixed or context</FieldLabel><Input value={yourContext} onChange={e => setYourContext(e.target.value)} placeholder="e.g. The AC issue was repaired the following day" /></div>
    <div style={{ marginBottom: "18px" }}><FieldLabel>Response tone</FieldLabel><ToneSelector tone={tone} setTone={setTone} /></div>
    <GenerateBtn can={can} loading={loading} onClick={() => onGenerate(prompt())} />
    {output && <OutputCard output={output} onRegenerate={() => onGenerate(prompt())} onCopy={onCopy} copied={copied} />}
  </div>;
}

function DisputeTool({ onGenerate, loading, output, copied, onCopy }) {
  const [review, setReview] = useState(""); const [disputeGround, setDisputeGround] = useState(""); const [propertyName, setPropertyName] = useState(""); const [yourContext, setYourContext] = useState("");
  const can = review.trim().length > 10 && !!disputeGround;
  const prompt = () => buildPrompt("dispute", { review, disputeGround, propertyName, yourContext });
  return <div>
    <div style={{ background: C.purpleSoft, border: `1px solid ${C.purpleBorder}`, borderRadius: "10px", padding: "12px 14px", marginBottom: "18px", fontSize: "13px", color: C.purple, lineHeight: "1.5" }}>⚖️ <strong>Dispute tool:</strong> Drafts a formal removal request to Airbnb support — not a public response.</div>
    <div style={{ marginBottom: "14px" }}><FieldLabel optional>Property name</FieldLabel><Input value={propertyName} onChange={e => setPropertyName(e.target.value)} placeholder="e.g. SugarDolphin Beach Condo" /></div>
    <div style={{ marginBottom: "14px" }}><FieldLabel>Grounds for dispute</FieldLabel><Select value={disputeGround} onChange={setDisputeGround} options={DISPUTE_GROUNDS} placeholder="Select grounds…" /></div>
    <div style={{ marginBottom: "14px" }}><FieldLabel>The review you want removed</FieldLabel><Textarea value={review} onChange={setReview} placeholder="Paste the exact review text here…" rows={4} /></div>
    <div style={{ marginBottom: "18px" }}><FieldLabel optional>Your evidence or context</FieldLabel><Textarea value={yourContext} onChange={setYourContext} placeholder="e.g. Guest threatened a bad review if we didn't provide a refund. Screenshots available." rows={3} max={500} /></div>
    <GenerateBtn can={can} loading={loading} label="Draft Dispute Message →" onClick={() => onGenerate(prompt())} />
    {output && <OutputCard output={output} onRegenerate={() => onGenerate(prompt())} onCopy={onCopy} copied={copied} />}
  </div>;
}

// ── Main app ────────────────────────────────────────────────────
export default function App() {
  const [page, setPage] = useState("landing");
  const [activeTool, setActiveTool] = useState("bad");
  const [loading, setLoading] = useState(false);
  const [outputs, setOutputs] = useState({ bad: "", positive: "", neutral: "", dispute: "" });
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState("");
  const [showPaywall, setShowPaywall] = useState(false);
  const [daysRemaining, setDaysRemaining] = useState(TRIAL_DAYS);

  useEffect(() => { getTrialStart(); setDaysRemaining(getTrialDaysRemaining()); }, []);

  const tool = TOOLS.find(t => t.id === activeTool);

  const handleGenerate = async (prompt) => {
    if (isPaywalled()) { setShowPaywall(true); return; }
    setLoading(true); setError("");
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ model: "claude-sonnet-4-20250514", max_tokens: 1000, messages: [{ role: "user", content: prompt }] }),
      });
      const data = await res.json();
      const text = data.content?.map(b => b.text || "").join("").trim();
      if (text) {
        setOutputs(prev => ({ ...prev, [activeTool]: text }));
        setDaysRemaining(getTrialDaysRemaining());
      } else { setError("Something went wrong. Please try again."); }
    } catch { setError("Connection error. Please try again."); }
    finally { setLoading(false); }
  };

  const handleCopy = () => { navigator.clipboard.writeText(outputs[activeTool]); setCopied(true); setTimeout(() => setCopied(false), 2000); };

  if (page === "landing") return <LandingPage onGetStarted={() => setPage("app")} />;

  const sharedProps = { onGenerate: handleGenerate, loading, output: outputs[activeTool], copied, onCopy: handleCopy };

  return <div style={{ fontFamily: "'Inter', -apple-system, sans-serif", background: C.sand, minHeight: "100vh" }}>
    {showPaywall && <PaywallModal onClose={() => setShowPaywall(false)} />}

    <div style={{ background: C.white, borderBottom: `1px solid ${C.border}`, padding: "16px 28px", display: "flex", alignItems: "center", justifyContent: "space-between", position: "sticky", top: 0, zIndex: 10 }}>
      <div style={{ display: "flex", alignItems: "center", gap: "10px", cursor: "pointer" }} onClick={() => setPage("landing")}>
        <div style={{ width: "34px", height: "34px", background: `linear-gradient(135deg, ${C.teal} 0%, ${C.tealDark} 100%)`, borderRadius: "9px", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "17px" }}>🏡</div>
        <div>
          <div style={{ fontSize: "16px", fontWeight: "800", color: C.ink, letterSpacing: "-0.4px" }}>Superhost Reply Suite</div>
          <div style={{ fontSize: "11px", color: C.muted, letterSpacing: "0.4px", textTransform: "uppercase" }}>AI Review Toolkit</div>
        </div>
      </div>
      {daysRemaining > 0
        ? <div style={{ background: C.tealLight, color: C.tealDark, fontSize: "12px", fontWeight: "600", padding: "5px 12px", borderRadius: "20px" }}>{daysRemaining} day{daysRemaining !== 1 ? "s" : ""} left in trial</div>
        : <a href={LS_CHECKOUT_URL} target="_blank" rel="noopener noreferrer" style={{ background: `linear-gradient(135deg, ${C.teal} 0%, ${C.tealDark} 100%)`, color: C.white, fontSize: "12px", fontWeight: "600", padding: "8px 14px", borderRadius: "8px", textDecoration: "none" }}>Unlock Full Access →</a>
      }
    </div>

    <div style={{ background: C.white, borderBottom: `1px solid ${C.border}`, padding: "0 28px", display: "flex", gap: "0", overflowX: "auto" }}>
      {TOOLS.map(t => <button key={t.id} onClick={() => { setActiveTool(t.id); setError(""); }} style={{ padding: "14px 18px", border: "none", background: "none", cursor: "pointer", fontSize: "13px", fontWeight: activeTool === t.id ? "700" : "500", color: activeTool === t.id ? t.color : C.muted, borderBottom: activeTool === t.id ? `2.5px solid ${t.color}` : "2.5px solid transparent", transition: "all 0.15s", whiteSpace: "nowrap", display: "flex", alignItems: "center", gap: "6px" }}>
        <span>{t.icon}</span> {t.label}
        {outputs[t.id] && <span style={{ width: "7px", height: "7px", borderRadius: "50%", background: C.teal, display: "inline-block" }} />}
      </button>)}
    </div>

    <div style={{ maxWidth: "680px", margin: "0 auto", padding: "32px 20px 80px" }}>
      <div style={{ marginBottom: "28px" }}>
        <div style={{ fontSize: "11px", fontWeight: "700", color: tool.color, letterSpacing: "1px", textTransform: "uppercase", marginBottom: "6px" }}>{tool.icon} {tool.label}</div>
        <div style={{ fontSize: "24px", fontWeight: "800", color: C.ink, letterSpacing: "-0.5px", lineHeight: "1.25", marginBottom: "6px" }}>{tool.headline}</div>
        <div style={{ fontSize: "14px", color: C.muted, lineHeight: "1.55" }}>{tool.sub}</div>
      </div>

      <div style={{ background: C.white, border: `1px solid ${C.border}`, borderRadius: "14px", padding: "24px", boxShadow: "0 1px 4px rgba(0,0,0,0.05)" }}>
        {activeTool === "bad"      && <BadReviewTool      {...sharedProps} />}
        {activeTool === "positive" && <PositiveReviewTool {...sharedProps} />}
        {activeTool === "neutral"  && <NeutralReviewTool  {...sharedProps} />}
        {activeTool === "dispute"  && <DisputeTool        {...sharedProps} />}
      </div>

      {error && <div style={{ background: C.redSoft, border: `1px solid ${C.redBorder}`, borderRadius: "10px", padding: "12px 14px", marginTop: "14px", fontSize: "13px", color: C.red }}>{error}</div>}
      <div style={{ textAlign: "center", marginTop: "40px", fontSize: "12px", color: C.muted }}>Superhost Reply Suite · Built for serious hosts</div>
    </div>
  </div>;
}
